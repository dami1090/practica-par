#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"


struct
 {
 int codigoProducto;
 char* descrip;// cadena string dinamico,lo guardo en un buffer y dsp le hago un len , lo genero cn un malloc;
 float importe;
 int cantidad;
 int activo;
 }typedef eProducto;

 eProducto* producto_new(void);
 int parserProducto(FILE* pFile , ArrayList* pArrayListProducto);
 void producto_print(eProducto* lista);
 char* charDynamic(char buffer[]);





