#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "modeloparcial.h"

int parserProducto(FILE* pFile, ArrayList* pArrayListProducto)
{
    char auxCodigo[10], auxEstado[10],auxPrecio[10];
    char auxDescrip[500],auxCantidad[100];
    eProducto* producto;
    char* s;
    fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxCodigo,auxDescrip,auxPrecio,auxCantidad,auxEstado);
    while(!feof(pFile))
    {
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxCodigo,auxDescrip,auxPrecio,auxCantidad,auxEstado);


        producto=producto_new();
        producto->codigoProducto=atoi(auxCodigo);
        producto->importe=atof(auxPrecio);
        producto->cantidad=atoi(auxCantidad);
        producto->activo=atoi(auxEstado);

        s=charDynamic(auxDescrip);
        producto->descrip=s;

        pArrayListProducto->add(pArrayListProducto,producto);

    }

    return 0;
}




eProducto* producto_new(void)
{

    eProducto* returnAux = (eProducto*)calloc(1,sizeof(eProducto));

    return returnAux;

}

void producto_print(eProducto* lista)
{
    printf("%d--%s--%.2f--%d--%d\n",lista->codigoProducto,lista->descrip,lista->importe,lista->cantidad,lista->activo);
}

char* charDynamic(char buffer[])
{

    char* texto;

    texto = (char*)malloc(sizeof(char)*(strlen(buffer)+1));
    if(texto != NULL)
    {
        strcpy(texto,buffer);

    }

    printf("texto\n: %s\n", texto);
     return texto;
}
