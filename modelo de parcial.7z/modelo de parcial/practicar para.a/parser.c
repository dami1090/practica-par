#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(FILE* pFile, ArrayList* pArrayListEmployee)
{
    char auxID[10], auxEstado[10];
    char auxName[100], auxLastName[100];
    Employee* Empleado;
    fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",auxID,auxName,auxLastName,auxEstado);
    while(!feof(pFile))
    {
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",auxID,auxName,auxLastName,auxEstado);

        Empleado=employee_new();
        Empleado->id=atoi(auxID);

        strcpy(Empleado->name,auxName);
        strcpy(Empleado->lastName,auxLastName);
        if(strcmp(auxEstado,"true")==0)
        {
            Empleado->isEmpty=1;
        }
        else
        {
            Empleado->isEmpty=0;
        }
       // employee_print(Empleado);
        pArrayListEmployee->add(pArrayListEmployee,Empleado);

    }

    return 0;
}
